document.addEventListener("DOMContentLoaded", function() {
    console.log("Assignment Professors website loaded.");
});